import pandas as pd

def process_player_projection_data(all_players_data):
    # Convert the list of player data into a pandas DataFrame
    all_players_df = pd.DataFrame(all_players_data)

    # Create a new column 'matchup' combining 'team' and 'opp' columns
    all_players_df['matchup'] = all_players_df['team'] + " vs " + all_players_df['opp']

    # Define the columns to keep in the DataFrame
    columns_to_keep = [
        'name', 'position', 'team', 'opp', 'minutes', 'possessions', 'fd_points', 'points', 'assists', 'rebounds', 
        'offensive_rebounds', 'defensive_rebounds', 'blocks', 'steals', 'fouls', 'turnovers', 'two_pt_attempts', 
        'two_pt_fg', 'three_pt_attempts', 'three_pt_fg', 'free_throw_attempts', 'free_throws_made', 'roster_pos', 
        'confirmed', 'double_doubles', 'triple_doubles', 'injury', 'site', 'fd_std', 'fd_25_percentile', 
        'fd_50_percentile', 'fd_75_percentile', 'fd_85_percentile', 'fd_95_percentile', 'fd_99_percentile', 
        'timestamp', 'date', 'slate_id', 'gid', 'matchup'
    ]

    # Filter the DataFrame to include only the defined columns
    all_players_df = all_players_df[columns_to_keep]

    # Rename the 'name' column to 'player_names'
    all_players_df.rename(columns={'name': 'player_names'}, inplace=True)

    # Remove duplicate rows based on the 'player_names' column
    all_players_df = all_players_df.drop_duplicates(subset='player_names')
    
    # Return the processed DataFrame
    return all_players_df


